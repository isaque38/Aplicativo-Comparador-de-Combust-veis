<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
android:layout_width="match_parent"
android:layout_height="match_parent"
android:padding="16dp"
android:orientation="vertical">

<EditText
android:id="@+id/etGasolina"
android:layout_width="match_parent"
android:layout_height="wrap_content"
android:hint="Preço da Gasolina (R$)"
android:inputType="numberDecimal"/>

<EditText
android:id="@+id/etEtanol"
android:layout_width="match_parent"
android:layout_height="wrap_content"
android:hint="Preço do Etanol (R$)"
android:inputType="numberDecimal"/>

<Button
android:id="@+id/btnCalcular"
android:layout_width="match_parent"
android:layout_height="wrap_content"
android:text="Calcular"/>

<TextView
android:id="@+id/tvResultado"
android:layout_width="match_parent"
android:layout_height="wrap_content"
android:text="Resultado"
android:textSize="18sp"
android:layout_marginTop="20dp"/>
</LinearLayout>