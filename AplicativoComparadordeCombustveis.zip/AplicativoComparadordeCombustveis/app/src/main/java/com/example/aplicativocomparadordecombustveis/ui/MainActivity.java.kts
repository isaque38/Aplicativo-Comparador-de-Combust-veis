/*
*@author: Isaque de Lima Vieira
*RA: 1110482123042
*/
package com.example.comparadordecombustiveis

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var etGasolina: EditText? = null
    private var etEtanol: EditText? = null
    private var tvResultado: TextView? = null
    private var btnCalcular: Button? = null

    @Override
    protected fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etGasolina = findViewById(R.id.etGasolina)
        etEtanol = findViewById(R.id.etEtanol)
        tvResultado = findViewById(R.id.tvResultado)
        btnCalcular = findViewById(R.id.btnCalcular)

        btnCalcular.setOnClickListener(object : OnClickListener() {
            @Override
            fun onClick(v: View?) {
                calcularMelhorCombustivel()
            }
        })
    }

    private fun calcularMelhorCombustivel() {
        val precoGasolina: Double = Double.parseDouble(etGasolina.getText().toString())
        val precoEtanol: Double = Double.parseDouble(etEtanol.getText().toString())

        if (precoEtanol <= (precoGasolina * 0.70)) {
            tvResultado.setText("É mais vantajoso abastecer com Etanol.")
        } else {
            tvResultado.setText("É mais vantajoso abastecer com Gasolina.")
        }
    }
}